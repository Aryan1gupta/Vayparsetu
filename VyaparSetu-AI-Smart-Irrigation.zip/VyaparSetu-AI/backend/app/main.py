from __future__ import annotations
import os
import hashlib
import secrets
import re
from pathlib import Path
from typing import Literal
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv(Path(__file__).resolve().parents[1] / ".env")

AI_PROVIDER = os.getenv("AI_PROVIDER", "demo").strip().lower()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip()

app = FastAPI(title="VyaparSetu AI API", version="0.1.0",
              description="Team CodeBrain's farmer-to-market prototype API.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("FRONTEND_ORIGIN", "http://localhost:5173"),
                   "http://127.0.0.1:5173"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

# Explicitly synthetic sample records for prototype/demo use only.
MARKET_DATA = [
    {"crop":"Wheat / गेहूँ","market":"Prayagraj (demo)","price":2275,"unit":"₹/quintal","date":"Demo sample","source":"Demo data — not a live quote"},
    {"crop":"Wheat / गेहूँ","market":"Lucknow (demo)","price":2310,"unit":"₹/quintal","date":"Demo sample","source":"Demo data — not a live quote"},
    {"crop":"Rice / धान","market":"Prayagraj (demo)","price":2180,"unit":"₹/quintal","date":"Demo sample","source":"Demo data — not a live quote"},
    {"crop":"Potato / आलू","market":"Varanasi (demo)","price":950,"unit":"₹/quintal","date":"Demo sample","source":"Demo data — not a live quote"},
    {"crop":"Mustard / सरसों","market":"Lucknow (demo)","price":5650,"unit":"₹/quintal","date":"Demo sample","source":"Demo data — not a live quote"},
]
LISTINGS = [
    {"id":1,"crop":"Wheat / गेहूँ","quantity":100,"unit":"kg","location":"Prayagraj, UP","expected_price":24,"notes":"Clean grain; sample listing","seller":"Demo farmer","status":"Available","demo":True},
    {"id":2,"crop":"Mustard / सरसों","quantity":250,"unit":"kg","location":"Kaushambi, UP","expected_price":58,"notes":"Harvest-ready; sample listing","seller":"Demo farmer","status":"Available","demo":True},
]
ENQUIRIES = []
USERS = []
TOKENS = {}
ORDERS = []
DEMANDS = []
VERIFICATION_REQUESTS = []
next_demand_id = 1
next_id = 3
next_user_id = 1
next_order_id = 1

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: str = Field(min_length=5, max_length=200)
    password: str = Field(min_length=8, max_length=200)
    role: Literal["farmer", "buyer"] = "farmer"

class LoginRequest(BaseModel):
    email: str = Field(min_length=5, max_length=200)
    password: str = Field(min_length=8, max_length=200)

class OrderRequest(BaseModel):
    listing_id: int
    quantity: float = Field(gt=0, le=10000000)
    delivery_location: str = Field(min_length=3, max_length=200)

def password_hash(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 180000)
    return salt.hex(), digest.hex()

def safe_user(user: dict) -> dict:
    return {"id": user["id"], "name": user["name"], "email": user["email"], "role": user["role"]}

def current_user(authorization: str | None) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Please sign in to continue.")
    token = authorization.split(" ", 1)[1].strip()
    user_id = TOKENS.get(token)
    user = next((u for u in USERS if u["id"] == user_id), None)
    if not user:
        raise HTTPException(status_code=401, detail="Session expired. Please sign in again.")
    return user

@app.post("/api/auth/register")
def register(payload: RegisterRequest):
    global next_user_id
    email = payload.email.strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise HTTPException(status_code=422, detail="Enter a valid email address.")
    if any(u["email"] == email for u in USERS):
        raise HTTPException(status_code=409, detail="An account with this email already exists. Please sign in.")
    salt, digest = password_hash(payload.password)
    user = {"id": next_user_id, "name": payload.name.strip(), "email": email, "role": payload.role, "salt": salt, "password_hash": digest}
    next_user_id += 1
    USERS.append(user)
    token = secrets.token_urlsafe(32)
    TOKENS[token] = user["id"]
    return {"user": safe_user(user), "access_token": token, "token_type": "bearer"}

@app.post("/api/auth/login")
def login(payload: LoginRequest):
    email = payload.email.strip().lower()
    user = next((u for u in USERS if u["email"] == email), None)
    if not user:
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    salt = bytes.fromhex(user["salt"])
    _, digest = password_hash(payload.password, salt)
    if not secrets.compare_digest(digest, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    token = secrets.token_urlsafe(32)
    TOKENS[token] = user["id"]
    return {"user": safe_user(user), "access_token": token, "token_type": "bearer"}

@app.get("/api/auth/me")
def auth_me(authorization: str | None = Header(default=None)):
    return {"user": safe_user(current_user(authorization))}

@app.get("/api/orders")
def get_orders(authorization: str | None = Header(default=None)):
    user = current_user(authorization)
    items = [o for o in ORDERS if o["buyer_id"] == user["id"]] if user["role"] == "buyer" else [o for o in ORDERS if o["seller_id"] == user["id"]]
    return {"items": items, "mode": "in-memory prototype"}

@app.post("/api/orders")
def create_order(payload: OrderRequest, authorization: str | None = Header(default=None)):
    global next_order_id
    user = current_user(authorization)
    if user["role"] != "buyer":
        raise HTTPException(status_code=403, detail="Only buyer accounts can place orders. Create or sign in to a buyer account.")
    listing = next((item for item in LISTINGS if item["id"] == payload.listing_id), None)
    if not listing:
        raise HTTPException(status_code=404, detail="This crop listing is no longer available.")
    if payload.quantity > listing["quantity"]:
        raise HTTPException(status_code=400, detail=f"Only {listing['quantity']} {listing['unit']} is available.")
    if listing.get("seller_id") == user["id"]:
        raise HTTPException(status_code=400, detail="You cannot order your own crop listing.")
    listing["quantity"] = round(listing["quantity"] - payload.quantity, 3)
    order = {"id": next_order_id, "listing_id": listing["id"], "crop": listing["crop"], "quantity": payload.quantity,
             "unit": listing["unit"], "unit_price": listing["expected_price"], "total_price": round(payload.quantity * listing["expected_price"], 2),
             "delivery_location": payload.delivery_location.strip(), "buyer_id": user["id"], "buyer_name": user["name"],
             "seller_id": listing.get("seller_id"), "seller": listing["seller"], "status": "Order placed (demo)", "tracking_stage": "confirmed", "tracking_history": [{"stage": "confirmed", "note": "Order placed in prototype", "demo": True}], "payment_status": "No payment collected"}
    next_order_id += 1
    ORDERS.insert(0, order)
    return {"item": order, "message": "Prototype order placed. No payment has been collected."}

class DemandRequest(BaseModel):
    crop: str = Field(min_length=2, max_length=100)
    quantity: float = Field(gt=0, le=10000000)
    unit: Literal["kg", "quintal", "tonne"] = "kg"
    quality: str = Field(default="Standard", max_length=100)
    delivery_location: str = Field(min_length=2, max_length=120)
    budget_per_unit: float | None = Field(default=None, gt=0, le=100000000)

class LandedCostRequest(BaseModel):
    listing_id: int
    distance_km: float = Field(ge=0, le=5000)
    transport_rate_per_km: float = Field(default=8, gt=0, le=10000)
    extra_charges: float = Field(default=0, ge=0, le=10000000)

class VerificationRequest(BaseModel):
    business_name: str = Field(min_length=2, max_length=160)
    mobile: str = Field(min_length=7, max_length=25)
    gstin_or_registration: str = Field(default="", max_length=40)
    account_type: str = Field(default="Individual producer", max_length=80)

class TrackingRequest(BaseModel):
    stage: Literal["confirmed", "packed", "dispatched", "delivered", "issue"]
    note: str = Field(default="", max_length=300)

@app.post("/api/demands")
def create_demand(payload: DemandRequest, authorization: str | None = Header(default=None)):
    global next_demand_id
    user = current_user(authorization)
    if user["role"] != "buyer":
        raise HTTPException(status_code=403, detail="Only buyer accounts can publish a demand request.")
    item = {"id": next_demand_id, **payload.model_dump(), "buyer_id": user["id"], "buyer_name": user["name"],
            "status": "Open (prototype)", "mode": "prototype data"}
    next_demand_id += 1
    DEMANDS.insert(0, item)
    return {"item": item, "message": "Buyer demand saved in this prototype."}

@app.get("/api/demands")
def get_demands(authorization: str | None = Header(default=None)):
    user = current_user(authorization)
    items = DEMANDS if user["role"] == "farmer" else [d for d in DEMANDS if d["buyer_id"] == user["id"]]
    return {"items": items, "mode": "in-memory prototype"}

@app.get("/api/demand-matches/{demand_id}")
def match_demand(demand_id: int, authorization: str | None = Header(default=None)):
    user = current_user(authorization)
    demand = next((d for d in DEMANDS if d["id"] == demand_id), None)
    if not demand:
        raise HTTPException(status_code=404, detail="Demand request not found.")
    if user["role"] == "buyer" and demand["buyer_id"] != user["id"]:
        raise HTTPException(status_code=403, detail="You can only view matching results for your own demand.")
    matches = []
    wanted = demand["crop"].lower().strip()
    unit_to_kg = {"kg": 1.0, "quintal": 100.0, "tonne": 1000.0}
    demand_kg = demand["quantity"] * unit_to_kg[demand["unit"]]
    for listing in LISTINGS:
        if listing["quantity"] <= 0:
            continue
        crop = listing["crop"].lower()
        crop_match = wanted in crop or crop in wanted
        if not crop_match:
            continue
        available_kg = listing["quantity"] * unit_to_kg[listing["unit"]]
        available_in_demand_unit = available_kg / unit_to_kg[demand["unit"]]
        score = 55
        if available_kg >= demand_kg: score += 20
        elif available_kg > 0: score += round(20 * available_kg / demand_kg)
        if demand["delivery_location"].lower().split(',')[0] in listing["location"].lower(): score += 10
        if demand.get("budget_per_unit") is None or listing["expected_price"] <= demand["budget_per_unit"]: score += 10
        if demand["quality"].lower() in listing.get("notes", "").lower(): score += 5
        matches.append({"listing": listing, "match_score": min(score, 100), "quantity_sufficient": available_kg >= demand_kg,
                        "available_in_demand_unit": round(available_in_demand_unit, 3), "demand_unit": demand["unit"], "mode": "rule-based prototype match"})
    matches.sort(key=lambda x: (x["match_score"], x["available_in_demand_unit"]), reverse=True)
    total_supply = sum(m["available_in_demand_unit"] for m in matches)
    return {"demand": demand, "matches": matches, "aggregate_available_quantity": total_supply,
            "can_fulfil_by_aggregation": total_supply >= demand["quantity"],
            "notice": "Prototype rule-based match using entered listings only; not a trained AI prediction."}

@app.post("/api/landed-cost")
def landed_cost(payload: LandedCostRequest, authorization: str | None = Header(default=None)):
    current_user(authorization)
    listing = next((x for x in LISTINGS if x["id"] == payload.listing_id), None)
    if not listing:
        raise HTTPException(status_code=404, detail="Crop listing not found.")
    transport = round(payload.distance_km * payload.transport_rate_per_km, 2)
    product_price_per_unit = round(listing["expected_price"], 2)
    # Allocate the illustrative transport and extra charges across this listing's available quantity.
    divisor = max(float(listing["quantity"]), 1.0)
    transport_per_unit = round(transport / divisor, 2)
    extra_per_unit = round(payload.extra_charges / divisor, 2)
    return {"listing_id": listing["id"], "product_price_per_unit": product_price_per_unit,
            "estimated_transport_total": transport, "estimated_transport_per_unit": transport_per_unit,
            "extra_charges_total": payload.extra_charges, "extra_charges_per_unit": extra_per_unit,
            "estimated_landed_total": round(product_price_per_unit + transport_per_unit + extra_per_unit, 2),
            "distance_km": payload.distance_km, "transport_rate_per_km": payload.transport_rate_per_km,
            "mode": "illustrative estimate", "notice": "Transport rate and distance are user-entered estimates, not a carrier quote. Transport is divided across the listing's available quantity."}

@app.get("/api/trust/summary")
def trust_summary(authorization: str | None = Header(default=None)):
    user = current_user(authorization)
    completed = sum(1 for o in ORDERS if (o.get("seller_id") == user["id"] or o.get("buyer_id") == user["id"]) and o.get("tracking_stage") == "delivered")
    request = next((r for r in VERIFICATION_REQUESTS if r["user_id"] == user["id"]), None)
    return {"user_id": user["id"], "account_role": user["role"], "verification_status": request["status"] if request else "unverified",
            "business_name": request["business_name"] if request else None,
            "completed_demo_trades": completed, "rating": None,
            "notice": "Submitting details only creates a demo review request. Identity, GSTIN, phone OTP and business documents are not actually verified."}

@app.post("/api/trust/verification-request")
def submit_verification_request(payload: VerificationRequest, authorization: str | None = Header(default=None)):
    user = current_user(authorization)
    existing = next((r for r in VERIFICATION_REQUESTS if r["user_id"] == user["id"]), None)
    item = {"user_id": user["id"], **payload.model_dump(), "status": "pending review (demo)", "actual_checks_performed": False}
    if existing:
        existing.update(item)
    else:
        VERIFICATION_REQUESTS.append(item)
    return {"item": item, "notice": "Demo request recorded. No actual identity, GSTIN or OTP verification has taken place."}

@app.post("/api/orders/{order_id}/tracking")
def update_tracking(order_id: int, payload: TrackingRequest, authorization: str | None = Header(default=None)):
    user = current_user(authorization)
    order = next((o for o in ORDERS if o["id"] == order_id), None)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")
    if user["id"] not in (order.get("buyer_id"), order.get("seller_id")):
        raise HTTPException(status_code=403, detail="Only this order's buyer or seller can update tracking.")
    order["tracking_stage"] = payload.stage
    order["status"] = {"confirmed":"Order confirmed (demo)", "packed":"Packed (demo)", "dispatched":"Dispatched (demo)", "delivered":"Delivered (demo)", "issue":"Issue reported (demo)"}[payload.stage]
    order.setdefault("tracking_history", []).append({"stage": payload.stage, "note": payload.note, "demo": True})
    return {"item": order, "notice": "Demo tracking updated. No live GPS or courier integration is connected."}

class AskRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    language: Literal["en", "hi", "pa", "bn", "mr"] = "en"

class ListingRequest(BaseModel):
    crop: str = Field(min_length=2, max_length=100)
    quantity: float = Field(gt=0, le=10000000)
    unit: Literal["kg", "quintal", "tonne"] = "kg"
    location: str = Field(min_length=2, max_length=120)
    expected_price: float = Field(gt=0, le=100000000)
    notes: str = Field(default="", max_length=500)

class EnquiryRequest(BaseModel):
    listing_id: int
    buyer_name: str = Field(min_length=2, max_length=100)
    message: str = Field(min_length=3, max_length=500)

@app.get("/api/health")
def health():
    real_ai_ready = AI_PROVIDER == "openai" and bool(OPENAI_API_KEY)
    return {"status":"ok", "app":"VyaparSetu AI", "ai_mode":"live AI API" if real_ai_ready else "demo assistant",
            "ai_configured":real_ai_ready, "market_data_mode":"demo data"}

@app.get("/api/market-prices")
def market_prices():
    return {"mode":"demo", "notice":"Demo data only — not live mandi prices. Verify locally before selling.", "items":MARKET_DATA}

@app.get("/api/weather")
def weather():
    return {"mode":"demo", "notice":"Illustrative demo values only; not a live forecast.", "location":"Prayagraj, Uttar Pradesh",
            "temperature_c":31, "condition":"Partly cloudy (demo)", "rain_chance_percent":25,
            "irrigation_tip":"Demo guidance: check soil moisture and crop stage before irrigation. Do not irrigate solely from this sample."}

@app.get("/api/listings")
def get_listings():
    return {"items":LISTINGS, "mode":"in-memory prototype"}

@app.post("/api/listings")
def create_listing(payload: ListingRequest, authorization: str | None = Header(default=None)):
    global next_id
    user = current_user(authorization)
    if user["role"] != "farmer":
        raise HTTPException(status_code=403, detail="Only farmer accounts can publish crop listings.")
    item = {"id":next_id, **payload.model_dump(), "seller":user["name"], "seller_id":user["id"], "status":"Available", "demo":False}
    next_id += 1
    LISTINGS.insert(0, item)
    return {"item":item, "message":"Listing created for this running prototype."}

@app.post("/api/enquiries")
def create_enquiry(payload: EnquiryRequest):
    if not any(item["id"] == payload.listing_id for item in LISTINGS):
        raise HTTPException(status_code=404, detail="Listing not found")
    enquiry = {"id":len(ENQUIRIES)+1, **payload.model_dump(), "status":"New"}
    ENQUIRIES.append(enquiry)
    return {"item":enquiry, "message":"Buyer enquiry saved in this prototype."}

def demo_reply(message: str, language: str) -> str:
    lower = message.lower()
    if language in {"pa", "bn", "mr"}:
        if language == "pa":
            if any(w in lower for w in ["price", "market", "mandi", "ਭਾਅ", "ਕੀਮਤ"]):
                return "ਇਹ ਡੈਮੋ ਮੋਡ ਹੈ। ਦਿਖਾਏ ਗਏ ਮੰਡੀ ਭਾਅ ਨਮੂਨੇ ਹਨ, ਲਾਈਵ ਭਾਅ ਨਹੀਂ। ਵੇਚਣ ਤੋਂ ਪਹਿਲਾਂ ਸਥਾਨਕ ਮੰਡੀ ਜਾਂ ਭਰੋਸੇਯੋਗ ਅਧਿਕਾਰਤ ਸਰੋਤ ਤੋਂ ਅੱਜ ਦਾ ਭਾਅ ਅਤੇ ਆਵਾਜਾਈ ਖਰਚ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ।"
            if any(w in lower for w in ["water", "irrigat", "soil", "ਪਾਣੀ", "ਸਿੰਚਾਈ"]):
                return "ਡੈਮੋ ਸਲਾਹ: ਸਿੰਚਾਈ ਤੋਂ ਪਹਿਲਾਂ ਮਿੱਟੀ ਦੀ ਨਮੀ, ਫ਼ਸਲ ਦੀ ਅਵਸਥਾ ਅਤੇ ਸਥਾਨਕ ਮੌਸਮ ਦੀ ਜਾਂਚ ਕਰੋ। ਇਹ ਪ੍ਰੋਟੋਟਾਈਪ ਲਾਈਵ ਮੌਸਮ ਜਾਂ ਮਿੱਟੀ ਸੈਂਸਰ ਨਾਲ ਨਹੀਂ ਜੁੜਿਆ।"
            return "ਸਤ ਸ੍ਰੀ ਅਕਾਲ! ਮੈਂ ਟ੍ਰੇਡ ਮਿੱਤਰ ਦਾ ਡੈਮੋ ਸਹਾਇਕ ਹਾਂ। ਮੈਂ ਫ਼ਸਲ ਵੇਚਣ, ਮੰਡੀ ਦੀ ਤੁਲਨਾ ਅਤੇ ਪਾਣੀ ਬਚਾਉਣ ਬਾਰੇ ਆਮ ਜਾਣਕਾਰੀ ਦੇ ਸਕਦਾ ਹਾਂ। ਮਹੱਤਵਪੂਰਨ ਫ਼ੈਸਲੇ ਤੋਂ ਪਹਿਲਾਂ ਸਥਾਨਕ ਭਰੋਸੇਯੋਗ ਸਰੋਤ ਤੋਂ ਪੁਸ਼ਟੀ ਕਰੋ।"
        if language == "bn":
            if any(w in lower for w in ["price", "market", "mandi", "দাম", "বাজার"]):
                return "এটি ডেমো মোড। দেখানো বাজারদর নমুনা, লাইভ দর নয়। বিক্রির আগে স্থানীয় বাজার বা নির্ভরযোগ্য সরকারি উৎস থেকে আজকের দাম, গুণমানের কাটতি এবং পরিবহন খরচ যাচাই করুন।"
            if any(w in lower for w in ["water", "irrigat", "soil", "জল", "সেচ"]):
                return "ডেমো পরামর্শ: সেচের আগে মাটির আর্দ্রতা, ফসলের পর্যায় এবং স্থানীয় আবহাওয়ার নির্ভরযোগ্য পূর্বাভাস যাচাই করুন। এই প্রোটোটাইপ লাইভ আবহাওয়া বা মাটির সেন্সরের সঙ্গে যুক্ত নয়।"
            return "নমস্কার! আমি ট্রেড মিত্রের ডেমো সহায়ক। ফসল বিক্রি, বাজারদর তুলনা এবং জল সাশ্রয়ী চাষ সম্পর্কে সাধারণ তথ্য দিতে পারি। গুরুত্বপূর্ণ সিদ্ধান্তের আগে স্থানীয় নির্ভরযোগ্য উৎস থেকে যাচাই করুন।"
        if any(w in lower for w in ["price", "market", "mandi", "भाव", "बाजार"]):
            return "हा डेमो मोड आहे. दाखवलेले बाजारभाव नमुना आहेत, थेट बाजारभाव नाहीत. विक्रीपूर्वी स्थानिक बाजारातून आजचा भाव, गुणवत्ता कपात आणि वाहतूक खर्च तपासा."
        if any(w in lower for w in ["water", "irrigat", "soil", "पाणी", "सिंचन"]):
            return "डेमो सल्ला: सिंचनापूर्वी मातीतील ओलावा, पिकाची अवस्था आणि स्थानिक हवामानाचा विश्वासार्ह अंदाज तपासा. हे प्रोटोटाइप थेट हवामान किंवा मातीच्या सेन्सरशी जोडलेले नाही."
        return "नमस्कार! मी ट्रेड मित्रचा डेमो सहाय्यक आहे. पीक विक्री, बाजारभाव तुलना आणि पाणी बचत याबद्दल सामान्य माहिती देऊ शकतो. महत्त्वाच्या निर्णयांपूर्वी स्थानिक विश्वासार्ह स्रोतांकडून खात्री करा."
    if language == "hi":
        if any(w in lower for w in ["भाव", "price", "कीमत", "मंडी"]):
            return ("यह डेमो मोड है: बाजार भाव के नमूने केवल परीक्षण के लिए हैं, लाइव मंडी भाव नहीं। "
                    "बेचने से पहले अपने नज़दीकी मंडी/विश्वसनीय आधिकारिक स्रोत से आज का भाव और गुणवत्ता कटौती जाँचें। "
                    "ऐप के 'बाज़ार भाव' पेज पर तुलना का उदाहरण देखें।")
        if any(w in lower for w in ["पानी", "सिंचाई", "irrigat", "water"]):
            return ("डेमो सलाह: सिंचाई से पहले मिट्टी की नमी, फसल की अवस्था और स्थानीय मौसम की पुष्टि करें। "
                    "यह ऐप अभी लाइव मौसम या मिट्टी सेंसर से जुड़ा नहीं है। सही मात्रा और समय के लिए स्थानीय कृषि विशेषज्ञ की सलाह लें।")
        return ("नमस्ते! मैं Trade Mitr का डेमो सहायक हूँ। मैं फसल बेचने, बाज़ार तुलना और पानी बचाने से जुड़े सामान्य सवालों में मदद कर सकता हूँ। "
                "अभी लाइव AI कनेक्ट नहीं है। अपने सवाल के साथ फसल और जिला भी लिखें।")
    if any(w in lower for w in ["price", "market", "mandi", "sell"]):
        return ("This is demo mode. The displayed prices are synthetic examples, not live mandi quotes. "
                "Before selling, verify today's price, grade/quality deductions, transport cost and buyer credibility with a trusted local source.")
    if any(w in lower for w in ["water", "irrigat", "soil", "rain"]):
        return ("Demo guidance: check soil moisture, crop stage and a trusted local forecast before irrigating. "
                "This prototype is not connected to live weather or soil sensors. Confirm crop-specific advice with a local agriculture expert.")
    return ("Hello! I'm the Trade Mitr demo assistant. I can help explain market comparisons, crop listings and general water-conscious farming. "
            "Live AI is not configured yet. Add an API key to backend/.env to enable AI responses. Please verify important farming and trading decisions with trusted local sources.")

@app.post("/api/trade-mitr")
async def trade_mitr(payload: AskRequest):
    if AI_PROVIDER == "openai" and OPENAI_API_KEY:
        system_prompt = (
            "You are Trade Mitr, a cautious, friendly agriculture market assistant for farmers in Uttar Pradesh, India. "
            "Respond in the selected language: English (en), Hindi (hi), Punjabi (pa), Bengali (bn), or Marathi (mr). Use plain language and short actionable steps. "
            "Never invent current mandi prices, weather, government scheme eligibility, or guaranteed yield/income. "
            "State when information is unavailable and advise checking official/local sources. "
            "You do not have live market/weather data unless explicitly provided in the conversation. "
            "For pesticide, medical, legal, financial or crop-critical decisions, avoid unsupported specifics and suggest a qualified local expert."
        )
        user_content = f"Language code: {payload.language}\nFarmer question: {payload.message}"
        try:
            async with httpx.AsyncClient(timeout=35) as client:
                response = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type":"application/json"},
                    json={"model":OPENAI_MODEL,"messages":[{"role":"system","content":system_prompt},{"role":"user","content":user_content}],
                          "temperature":0.3}
                )
            if response.status_code >= 400:
                raise HTTPException(status_code=502, detail=f"AI provider returned HTTP {response.status_code}. Check the API key, model, and account access.")
            data = response.json()
            answer = data["choices"][0]["message"]["content"]
            return {"answer":answer, "mode":"live AI API", "disclaimer":"AI-generated guidance can be wrong. Verify important decisions locally."}
        except httpx.TimeoutException:
            raise HTTPException(status_code=504, detail="AI request timed out. Please try again.")
        except HTTPException:
            raise
        except Exception:
            raise HTTPException(status_code=502, detail="Could not reach the AI service. Check backend logs and connection.")
    return {"answer":demo_reply(payload.message, payload.language), "mode":"demo assistant",
            "disclaimer":"Demo response — configure an AI API key for live AI. Verify important decisions locally."}
